All the prefabs data used in the project will copied to under this directory.
Studio managed directory.
